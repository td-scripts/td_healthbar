window.addEventListener('message', function(event) {
    if (event.data.action === "updateStatus") {
        let healthBar = document.getElementById("healthBar");
        let armorBar = document.getElementById("armorBar");
        
        let health = event.data.health;
        let armor = event.data.armor;

        
        health = Math.max(0, Math.min(100, health));
        armor = Math.max(0, Math.min(100, armor));

        
        healthBar.style.width = health + "%";
        armorBar.style.width = armor + "%";

       
        if (health > 50) {
            healthBar.style.backgroundColor = "#00ff00"; // Green
        } else if (health > 25) {
            healthBar.style.backgroundColor = "#ffae00"; // Orange
        } else {
            healthBar.style.backgroundColor = "#ff0000"; // Red
        }

        
        if (armor > 50) {
            armorBar.style.backgroundColor = "#007bff"; // Blue
        } else {
            armorBar.style.backgroundColor = "#0056b3"; // Dark Blue
        }
    }
});
