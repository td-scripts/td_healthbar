fx_version 'cerulean'
game 'gta5'

author 'Tond'
description 'Animated custom healthbar for ESX'
version '1.0'

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/script.js',
    'ui/style.css'
}

client_scripts {
    'client.lua'
}
