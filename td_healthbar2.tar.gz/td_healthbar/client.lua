local playerPed = PlayerPedId()

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(200)
        local playerPed = PlayerPedId()
        local health = (GetEntityHealth(playerPed) - 100) / (GetEntityMaxHealth(playerPed) - 100) * 100
        
        SendNUIMessage({
            action = "updateHealth",
            health = health
        })
    end
end)
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(200)
        local playerPed = PlayerPedId()
        local health = (GetEntityHealth(playerPed) - 100) / (GetEntityMaxHealth(playerPed) - 100) * 100
        local armor = GetPedArmour(playerPed) 

        SendNUIMessage({
            action = "updateStatus",
            health = health,
            armor = armor
        })
    end
end)